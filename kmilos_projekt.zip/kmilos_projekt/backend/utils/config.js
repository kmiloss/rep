require('dotenv').config()

const PORT = process.env.PORT

const password = process.env.ATLAS_PASS	;
const user = process.env.ATLAS_USER
const dbname = process.env.NODE_ENV === 'test'
? 'memories-test'
: 'memories-api';

const DB_URI = `mongodb+srv://${user}:${password}@milossa2107.1yel5q2.mongodb.net/${dbname}?retryWrites=true&w=majority`;

module.exports = {PORT, DB_URI}