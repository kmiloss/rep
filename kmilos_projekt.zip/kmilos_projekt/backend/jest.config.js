module.exports = {
    testEnvironment: 'node',
    verbose: true,
    testTimeout: 10000
}