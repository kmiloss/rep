const bcrypt = require('bcryptjs')
const User = require('../models/user')
const pomocni = require('./test_pomoc')
const mongoose = require('mongoose')
const supertest = require('supertest')
const app = require('../app')
const api = supertest(app)

describe('Kada imamo samo jednog korisnika u bazi', () =>{
  beforeEach(async () => {
    await User.deleteMany({})
    const password ="test"
    const passHash = await bcrypt.hash(password, 10)
    const korisnik = new User({email: 'klara2@gmail.com', name: 'antonia bilic',password: passHash, id: '1'})
    await korisnik.save()
  })

  test('stvaranje novog korisnika', async () =>{
    const pocetniKorisnici = await pomocni.korisniciUBazi();

    const novi = {
      email: 'klara3@gmail.com', name: 'km3',password: 'mojatajna', id: '2'
    }

    await api
    .post('/user/signup')
    .send(novi)
    .expect(201)
    .expect('Content-Type', /application\/json/)

    const korisniciKraj = await pomocni.korisniciUBazi()
    expect(korisniciKraj).toHaveLength(pocetniKorisnici.length + 1)

    const korImena = korisniciKraj.map(u => u.username)
    expect(korImena).toContain(novi.username)
  })


 


})

   test('ispravno vraca pogresku ako vec postoji email', async () =>{
    const pocetniKorisnici = await pomocni.korisniciUBazi()
    
    const novi = {
      email: 'klara3@gmail.com', name: 'km4',password: 'mojatajna2', id: '3'
    }
  
    await api
    .post('/user/signup')
    .send(novi)
    .expect(400)
    .expect('Content-Type', /application\/json/)
     
  
    const korisniciKraj = await pomocni.korisniciUBazi()
    expect(korisniciKraj).toHaveLength(pocetniKorisnici.length)
  }) 
 

afterAll(() => {
    mongoose.connection.close()
  })