const PostMessage = require('../models/postMessage')

const User =require('../models/user')

let pocetniPosts = [
  {
    id: 1,
    title: 'funny',
    message: 'i had a lovely day',
    name: 'klara milos',
    creator: '630023c419db3c952ba198b3',
    tags: [],
    selectedFile: "",
    likes: [],
    createdAt: '2022-08-20T00:18:58.393+00:00'
  },
  {
    id: 2,
    title: 'napokon',
    message: 'projekt ide kraju',
    name: 'klara milos',
    creator: '630023c419db3c952ba198b3',
    tags: [],
    selectedFile: "",
    likes: [],
    createdAt: '2021-08-20T00:18:58.393+00:00'
  }
]

const postsIzBaze = async () => {
  const postMessage = await PostMessage.find({})
  return postMessage.map(t => t.toJSON())
}

const nepostojeciId = async () => {
  const postMessage = new PostMessage({
    title: 'ne postoji id',
    message: 'nazalost',
    name:'klara milos' ,
    creator: '630023c419db3c952ba198b3',
    tags: [],
    selectedFile: "",
    likes: [] ,
    createdAt: '2022-08-18T00:18:58.393+00:00'
  });

  await postMessage.save()
  await postMessage.remove()

  return postMessage._id.toString()
}


const korisniciUBazi = async () => {
  const korisnici = await User.find({})
  return korisnici.map(k => k.toJSON())
}





module.exports = {
  pocetniPosts, postsIzBaze, nepostojeciId,korisniciUBazi
}
