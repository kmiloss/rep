const mongoose = require('mongoose')

const supertest = require('supertest')

const app = require('../App')

const PostMessage =require('../models/postMessage.js');

const pomocni =require('./test_pomoc');


const api = supertest(app)



beforeEach( async () => {
 await PostMessage.deleteMany({})
 let objekt= new PostMessage(pomocni.pocetniPosts[0])
 await objekt.save()
 objekt = new PostMessage(pomocni.pocetniPosts[1])
 await objekt.save()

})


test('POSTS se vraćaju kao JSON', async () => {
    await api
      .get('/posts/')
      .expect(200)
      .expect('Content-Type', /application\/json/)


  })

  test('dohvaca SVE rezultate', async () => {
    const odgovor = await api.get('/posts/')
    expect(odgovor.body.data).toHaveLength(pomocni.pocetniPosts.length)
   })
   
   test('dodavanje ispravnog posta', async () => {
    const noviPost= {
      id:3,
      title: 'uspjeh',
      message: 'dodan',
      name: 'klara milos',
      creator: '630023c419db3c952ba198b3',
      tags: [],
      selectedFile: "",
      likes: [],
      createdAt: '2022-08-20T00:18:58.393+00:00'
      
    }
    await api
    .post('/posts/')
    .send(noviPost)
    .expect(201)
    .expect('Content-Type', /application\/json/)

    
    const pNaKraju = await pomocni.postsIzBaze()
    expect(pNaKraju).toHaveLength(pomocni.pocetniPosts.length + 1)

   })
   
 

afterAll(async () => {
 await mongoose.connection.close() 
})
