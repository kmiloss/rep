const config = require('./utils/config')
const express = require('express')
require('express-async-errors')

const cors = require('cors')
const postRoutes = require( './routes/posts.js');
const userRouter = require( "./routes/user.js");
const mongoose = require('mongoose')


const app = express()


mongoose.connect(config.DB_URI,{ useNewUrlParser: true , useUnifiedTopology: true})
 .then(result => {
 console.log("Spojeni smo na bazu");
 }).catch(error => {
    console.log("Greška pri spajanju", error.message);
 });

 app.use(cors());
app.use(express.json())

mongoose.set('useFindAndModify', false);

app.use(express.static('build'))
app.use('/posts', postRoutes);
app.use("/user", userRouter);


module.exports = app